# CV-creator
developed this cv creator app in android studio (xml+java)
